# Run3Source
**it is quite literally the game run 3's source lmfao**

you need a webserver or a github page for the html to actually work.

### IF ANYONE KNOWS HOW TO DECOMPILE OPENFL SOURCE THAT WILL BE REALLY COOL LOL

i'll eventually add some explanations for some stuff if anyones interested in "modding" run 3
